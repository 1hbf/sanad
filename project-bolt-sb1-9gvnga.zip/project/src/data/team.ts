export const teamMembers = [
  {
    name: 'Hisham Alnabulsiyyah',
    role: 'Chief Executive Officer',
  },
  {
    name: 'Meshal Alsbah',
    role: 'Chief Technology Officer',
  },
  {
    name: 'Abdulaziz Alamre',
    role: 'Chief Medical Officer',
  },
  {
    name: 'Salman Alsaml',
    role: 'Chief Operations Officer',
  },
];